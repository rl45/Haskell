top =
  let x = True in
  let y = if x then 1 else 0 in
  if y == 1 then True else False
  