top =
  let id = \x -> x in
  let a1 = id 7 in
  let a2 = id True in
  True  
