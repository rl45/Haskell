top =
  if True then 1 else \x -> x