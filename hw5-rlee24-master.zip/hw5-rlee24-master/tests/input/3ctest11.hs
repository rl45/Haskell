top =
  head [1,2,3]