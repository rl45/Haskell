top =
  let id = \x -> x + 1 in
  let a1 = id 7 in
  let a2 = id True in
  True