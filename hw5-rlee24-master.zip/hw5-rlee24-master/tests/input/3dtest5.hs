top =
  (\x -> x x) (\x -> x x) 