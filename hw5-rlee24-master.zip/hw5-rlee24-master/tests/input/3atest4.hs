top =
  (\x -> x) 5