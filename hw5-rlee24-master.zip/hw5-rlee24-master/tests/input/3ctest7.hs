top =
  if True then \x -> x else \x -> x + 5