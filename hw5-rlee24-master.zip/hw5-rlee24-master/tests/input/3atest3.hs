top =
  let x = 5 in
  x