{-# LANGUAGE FlexibleInstances, OverloadedStrings, BangPatterns #-}

module Language.Nano.TypeCheck where

import Language.Nano.Types
import Language.Nano.Parser

import qualified Data.List as L
import           Text.Printf (printf)
import           Control.Exception (throw)

--------------------------------------------------------------------------------
typeOfFile :: FilePath -> IO Type
typeOfFile f = parseFile f >>= typeOfExpr

typeOfString :: String -> IO Type
typeOfString s = typeOfExpr (parseString s)

typeOfExpr :: Expr -> IO Type
typeOfExpr e = do
  let (!st, t) = infer initInferState preludeTypes e
  if (length (stSub st)) < 0 then throw (Error ("count Negative: " ++ show (stCnt st)))
  else return t

--------------------------------------------------------------------------------
-- Problem 1: Warm-up
--------------------------------------------------------------------------------

-- | Things that have free type variables
class HasTVars a where
  freeTVars :: a -> [TVar]

-- | Type variables of a type
instance HasTVars Type where
  freeTVars TInt = []
  freeTVars TBool = []
  freeTVars(t1 :=> t2) = L.nub(freeTVars t1 ++ freeTVars t2) --
  freeTVars(TVar x) = [x]
  freeTVars(TList t1) = freeTVars t1

-- | Free type variables of a poly-type (remove forall-bound vars)
instance HasTVars Poly where

    freeTVars (Mono t) = freeTVars t
    -- freeTVars (Forall a t) = L.nub(freeTVars t L.\\ [a])
    freeTVars(Forall ignoreVar t) = removeDuplicates (freeTVars t)
               where
                 removeDuplicates([]) = []
                 removeDuplicates (x:xs) = if x /= ignoreVar then [x] ++ removeDuplicates(xs) else removeDuplicates(xs)



-- | Free type variables of a type environment
instance HasTVars TypeEnv where
  freeTVars gamma   = concat [freeTVars s | (x, s) <- gamma]

-- | Lookup a variable in the type environment
lookupVarType :: Id -> TypeEnv -> Poly
lookupVarType x ((y, s) : gamma)
  | x == y    = s
  | otherwise = lookupVarType x gamma
lookupVarType x [] = throw (Error ("unbound variable: " ++ x))

-- | Extend the type environment with a new biding
extendTypeEnv :: Id -> Poly -> TypeEnv -> TypeEnv
extendTypeEnv x s gamma = (x,s) : gamma

-- | Lookup a type variable in a substitution;
--   if not present, return the variable unchanged
lookupTVar :: TVar -> Subst -> Type

 -- lookupTVar a sub = narrow a sub

lookupTVar a ((b, t) : gamma)
  | a == b = t
  | otherwise = lookupTVar a gamma
lookupTVar a [] = TVar a -- throw (Error ("lookupTVar"))

-- | Remove a type variable from a substitution
removeTVar :: TVar -> Subst -> Subst
--removeTVar a sub = error "TBD: removeTVar"

removeTVar a ((b, t) : gamma)
 | a == b = removeTVar a gamma
 | otherwise = ((b, t) : gamma)
removeTVar a [] = throw (Error ("lookupTVar"))

-- | Things to which type substitutions can be

class Substitutable a where
  apply :: Subst -> a -> a

-- | Apply substitution to type
instance Substitutable Type where

   apply sub (TVar n) = lookupTVar n sub
   apply sub (TList t1) = TList(apply sub t1)
   apply sub (TInt) = TInt
   apply sub (t1 :=> t2) = (apply sub t1) :=> (apply sub t2)
   apply sub (TBool) = TBool


-- | Apply substitution to poly-type
instance Substitutable Poly where
  apply sub (Mono TInt) = Mono TInt
  apply sub (Mono TBool) = Mono TBool
  apply sub (Mono (t1 :=> t2)) = Mono (t1 :=> t2)
  apply sub (Mono (TVar a)) = (Mono (TVar a))
  apply sub (Mono (TList t1)) = (Mono (TList t1))
  apply sub (Forall var poly) = Forall var (apply sub poly) -- poly == list "a"

-- | Apply substitution to (all poly-types in) another substitution
instance Substitutable Subst where
  apply sub to = zip keys $ map (apply sub) vals
    where
      (keys, vals) = unzip to

-- | Apply substitution to a type environment
instance Substitutable TypeEnv where
  apply sub gamma = zip keys $ map (apply sub) vals
    where
      (keys, vals) = unzip gamma

-- | Extend substitution with a new type assignment

-- >>> extendSubst [("a", TInt)] "b" TBool
-- [("b",Bool), ("a",Int)]

-- >>> extendSubst [("a", list "b")] "b" TBool
-- [("b",Bool), ("a",[Bool])]

-- Tests
-- >>> extendSubst [("a", TInt)] "b" (TList(TVar "a"))
-- [("b", [a]), ("a", Int)]

-- >>> extendSubst [("a", TInt)] "b" (TList(TInt))
-- [("b",[Int]),("a",Int)]

-- >>> extendSubst [("a", TInt)] "b" (TInt)
-- [("b",Int),("a",Int)]

-- >>> extendSubst [("b", TList (TInt))] "a" TInt

extendSubst :: Subst -> TVar -> Type -> Subst

extendSubst sub x t2 = L.nub([(x,t3)] ++ (map f sub))
  where f :: (TVar, Type) -> (TVar, Type)
        f (a, t) = (a, apply [(x, t2)] (t))
        t3       = apply (map f sub) (t2)
        -- f ("a", list "b") = ("a", list TBool) if x = "a" and t2 = TBool

-- extendSubst ((b, t) : gamma) a t2 = [(a, t2) , (b , result )]
--      where result = apply [(a, t2)] t

-- extendSubst sub a t =  map (apply sub) -- something with apply1 apply2??
--       where apply1 = apply sub (TVar a)
--             apply2 = apply sub (t)

-- apply [("a", list "b")] (TVar "b") -- "b"
-- apply [("a", list "b")] (TBool) -- Bool
-- apply [("a", list "b")] (TList (TVar "b")) -- [b]
-- apply [("a", list "b")] (TVar "a") -- [b]

-------------------------------------------------------------------------------
-- Problem 2: Unification
--------------------------------------------------------------------------------

-- | State of the type inference algorithm
data InferState = InferState {
    stSub :: Subst -- ^ current substitution
  , stCnt :: Int   -- ^ number of fresh type variables generated so far
} deriving (Eq,Show)

-- | Initial state: empty substitution; 0 type variables
initInferState = InferState [] 0

-- | Fresh type variable number n
freshTV n = TVar $ "a" ++ show n

-- | Extend the current substitution of a state with a new type assignment
extendState :: InferState -> TVar -> Type -> InferState
extendState (InferState sub n) a t = InferState (extendSubst sub a t) n

-- | Unify a type variable with a type;
--   if successful return an updated state, otherwise throw an error


-- >>> stSub $ unifyTVar initInferState "a" (list "b")
-- [("a",[b])]

-- >>> stSub $ unifyTVar initInferState "a" "a"
-- []

-- >>> stSub $ unifyTVar initInferState "a" (list "a")
-- *** Exception: Error {errMsg = "type error: cannot unify a and [a] (occurs check)"}
-- data InferState = InferState {
--   stSub :: Subst -- ^ current substitution
--  , stCnt :: Int   -- ^ number of fresh type variables generated so far }

unifyTVar :: InferState -> TVar -> Type -> InferState
unifyTVar st a t
  | TVar a == t = st
  | a `elem` (freeTVars t) = throw (Error ("type error unifyTVar")) -- st
  | otherwise = extendState st a t

--  | a `elem` (freeTVars stSub) = unifyTVar st a

-- | Unify two types;

-- >>> stSub $ unify initInferState TInt TInt
-- []

-- >>> stSub $ unify initInferState TInt TBool
-- *** Exception: Error {errMsg = "type error: cannot unify Int and Bool"}

-- >>> stSub $ unify initInferState ("a" :=> TInt) (TBool :=> "b")
-- [("b",Int),("a",Bool)]

-- >>> stSub $ unify initInferState (list "a") (list $ list "a")
-- *** Exception: Error {errMsg = "type error: cannot unify a and [a] (occurs check)"}

--   if successful return an updated state, otherwise throw an error
unify :: InferState -> Type -> Type -> InferState
-- unify st t1 t2 = error "TBD: unify"
-- >>> stSub $ unify initInferState TInt TInt
-- []

-- >>> stSub $ unify initInferState TInt TBool
-- *** Exception: Error {errMsg = "type error: cannot unify Int and Bool"}

-- >>> stSub $ unify initInferState ("a" :=> TInt) (TBool :=> "b")
-- [("b",Int),("a",Bool)]

-- >>> stSub $ unify initInferState (list "a") (list $ list "a")
-- *** Exception: Error {errMsg = "type error: cannot unify a and [a] (occurs check)"}

unify st (TVar t1) t2 = unifyTVar st t1 t2
unify st t1 (TVar t2) = unifyTVar st t2 t1
unify st (TList t1) (TList t2) =  unify st (t1) (t2)
unify st (TInt) (TBool) = throw (Error ("type error unify st TInt TBool"))
unify st (TVar t1 :=> t2) (t3 :=> t4) = InferState{ stSub = s3, stCnt = count }     -- InferState { stSub = s3, stCnt = count }
      where s1 = unify st t2 t4 -- InferState
            s2 = unify st (apply (stSub s1) t2) (apply (stSub s1) t4) -- InferState
            s3 = L.nub(extendSubst (stSub s1) (t1) t3)
            count = (stCnt st) + 1
unify st (t3 :=> t4)(TVar t1 :=> t2)  = InferState{ stSub = s3, stCnt = count }     -- InferState { stSub = s3, stCnt = count }
      where s1 = unify st t2 t4 -- InferState
            s2 = unify st (apply (stSub s1) t2) (apply (stSub s1) t4) -- InferState
            s3 = L.nub(extendSubst (stSub s1) (t1) t3)
            count = (stCnt st) + 1
unify st (TInt) (t1 :=> t2) = throw (Error ("type error (TInt) (t1 :=> t2)"))
unify st (TVar t1 :=> t2) (TInt)  = InferState{ stSub = (stSub st), stCnt = (stCnt st)}-- throw (Error ("type error (TVar t1 :=> t2) (TInt)"))
unify st (TBool) (TInt) = throw (Error ("type error (TBool) (TInt)"))
unify st t1 t2
  | t1 == t2 = InferState {stSub = stSub st, stCnt = stCnt st}

--------------------------------------------------------------------------------
-- Problem 3: Type Inference
--------------------------------------------------------------------------------

infer :: InferState -> TypeEnv -> Expr -> (InferState, Type)
infer st _   (EInt _)          = (st , TInt )
infer st _   (EBool _)         = (st , TBool )
infer st gamma (EVar x)        = (st ,lookupTVar  x (stSub st) )
infer st gamma (ELam x body)   = (st1, tx' :=> tBody)
  where
    tEnv' = extendTypeEnv x (Mono tx) gamma -- extendTypeEnv ID POLY TypeENV
    tx = freshTV (stCnt st)
    (st1, tBody) = infer st tEnv' body
    tx' = apply (stSub st1) tx

infer st gamma (EApp e1 e2)    = (st4, TInt)
  where
    (st1, t1) = infer st gamma e1
    st2       = unify st1 t1 TInt
    tEnv'     = apply (stSub st2) gamma
    (st3, t2) = infer st2 tEnv' e2
    st4       = unify st3 t2 TInt
infer st gamma (ELet x e1 e2)  = (infer st1 env2 e2)
    where
        (st1, t1) = infer st gamma e1
        env'      = apply (stSub st1) gamma
        s1        = generalize env' t1
        env2      = extendTypeEnv x s1 env'

infer st gamma (EBin op e1 e2) = infer st gamma asApp
  where
    asApp = EApp (EApp opVar e1) e2
    opVar = EVar (show op)
infer st gamma (EIf c e1 e2) = infer st gamma asApp
  where
    asApp = EApp (EApp (EApp ifVar c) e1) e2
    ifVar = EVar "if"
infer st gamma ENil = infer st gamma (EVar "[]")

-- generalize [("x", Mono $ TVar "a")] ( (TVar "a") :=> (TVar "a"))

-- | Generalize type variables inside a type
generalize :: TypeEnv -> Type -> Poly
generalize gamma t = check
  where
    check =   if a == []
                  then r1
                  else r2
    r1    =   Mono t
    r2    =   Forall (head a) (Mono t)
    a     =   L.nub(v)
    v     =   freeTVars t L.\\ freeTVars gamma     -- error "TBD: generalize" -- Forall TVar Poly

-- | Instantiate a polymorphic type into a mono-type with fresh type variables
instantiate :: Int -> Poly -> (Int, Type)
-- instantiate n p = throw (Error ("TBD: instantiate"))
-- instantiate n (Forall var ply) = (a, apply)
--   where
--     (a, b) = freshTV n

instantiate n (Mono t) = (n, t)
  where
      fn  = freshTV n

instantiate n (Forall as t) = (instantiate n m)
  where
      fn  = freshTV n
      m   = apply [(as, fn)] t


-- | Types of built-in operators and functions
preludeTypes :: TypeEnv
preludeTypes =
  [ ("+",    Mono $ TInt :=> TInt :=> TInt)
  , ("-",    error "TBD: -")
  , ("*",    error "TBD: *")
  , ("/",    error "TBD: /")
  , ("==",   error "TBD: ==")
  , ("!=",   error "TBD: !=")
  , ("<",    error "TBD: <")
  , ("<=",   error "TBD: <=")
  , ("&&",   error "TBD: &&")
  , ("||",   error "TBD: ||")
  , ("if",   error "TBD: if")
  -- lists:
  , ("[]",   error "TBD: []")
  , (":",    error "TBD: :")
  , ("head", error "TBD: head")
  , ("tail", error "TBD: tail")
  ]
